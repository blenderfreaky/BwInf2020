# BwInf

## Dateistruktur

```
.
└───Afg<Aufgabennummer><Aufgabenname>.pdf
│   └// Doku für Aufgabe <Aufgabennummer>
└───Afg<Aufgabennummer><Aufgabenname>
└───src
│   └───<Aufgabenname>
│   │   └// Hauptalgorithmus Code
│   └───<Aufgabenname>.CLI
│   │   └// Ausführended Code / Konsoleninterface
│   app
│   └───<Aufgabenname>.CLI.exe
│   │   └// Exe des Programms
│   └// Dateien die für Ausführung notwendig sind
│   └───[examples]
│       └// offiziele Beispielsdateien
```

## Team

TeamID: 00587

Teamname: Doge.NET

Teammitglieder: Nikolas Kilian & Johannes von Stoephasius